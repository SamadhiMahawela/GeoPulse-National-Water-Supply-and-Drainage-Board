# VES Backend — shared database &amp; API

A small server that gives every device running the VES Field Tool one shared
place to save surveys, so data recorded on any phone or laptop shows up for
everyone. Node.js + Express + SQLite. No cloud account is required to run it
— you can run it on a laptop, an office PC, or deploy it (guide below).

```
backend/
├── server.js            → starts the web server, wires everything together
├── db.js                → opens the SQLite database, creates the table
├── routes/surveys.js    → the API: list / get / save / delete surveys
├── middleware/auth.js   → checks the shared API key on every request
├── public/admin.html    → a browser dashboard to view all saved surveys
├── package.json
└── .env.example          → copy to .env and fill in your own values
```

## What this is (and isn't)

- **Is:** one small server + one SQLite database file, holding every survey
  from every device, reachable over the internet (or your office network) by
  URL + a shared API key.
- **Isn't:** a per-user login system. Everyone who has the URL and API key
  can read and write all surveys — appropriate for one team sharing one
  dataset. If you later need individual staff logins and permissions, that's
  a bigger addition — ask and it can be built on top of this.

---

## 1. Run it on your own computer first (to try it out)

You'll need [Node.js](https://nodejs.org) installed (v18 or newer).

```bash
cd backend
npm install
cp .env.example .env
```

Open `.env` and set a real `API_KEY` (any long random string — this is the
password every device will need to read/write data). Then:

```bash
npm start
```

You should see `VES backend listening on port 4000`. Test it:

```bash
curl http://localhost:4000/api/health
# {"ok":true,"time":...}

curl http://localhost:4000/api/surveys -H "x-api-key: your-key-here"
# []   (empty list — nothing saved yet)
```

Visit `http://localhost:4000/admin` in a browser to see the (empty, for now)
admin dashboard.

---

## 2. Point the app at it

In the VES Field Tool app, open the **Tools** tab → **Server sync**:

- **Server URL** — where this backend is reachable, e.g. `http://localhost:4000`
  while testing, or your real deployed URL later (see below)
- **API key** — the same value you put in `.env` as `API_KEY`

Tap **Save connection**, then **Test connection** to confirm it can reach the
server. From then on:
- Saving a survey on that device also pushes it to the server automatically
  (if offline, it just stays local and you can push it later)
- **Push all local surveys to server** — sends everything currently on this
  device up
- **Pull latest from server** — brings down everything from the server and
  merges it with what's on this device (whichever copy of a survey was
  edited more recently wins)

Do this on every phone/laptop that should share data, using the **same**
Server URL and API key.

---

## 3. Deploying it so field devices can actually reach it

Running it on your own laptop only works while that laptop is on and
reachable — fine for a quick test, not for daily field use. Pick one:

### Option A — Railway.app (easiest managed option)

1. Create a free account at [railway.app](https://railway.app).
2. **New Project → Deploy from GitHub repo** (push this `backend/` folder to
   a GitHub repo first — private is fine), or use Railway's CLI to deploy the
   folder directly.
3. Add a **Volume** and mount it at, e.g., `/data`. Set the environment
   variable `DB_PATH=/data/ves.db` so the database survives restarts/redeploys.
4. Set environment variables `API_KEY` (your long random secret) and
   optionally `PORT` (Railway usually sets this for you).
5. Deploy. Railway gives you a public URL like
   `https://ves-backend-production.up.railway.app` — that's your **Server URL**.

### Option B — Render.com

1. Create an account at [render.com](https://render.com).
2. **New → Web Service**, connect the repo containing `backend/`.
3. Build command: `npm install`. Start command: `npm start`.
4. Add a **Disk** (Render's persistent storage) mounted at `/data`, and set
   `DB_PATH=/data/ves.db`. Note: persistent disks need a paid instance type —
   Render's free tier resets its filesystem on every restart, which would
   silently wipe the database.
5. Set the `API_KEY` environment variable.
6. Deploy — Render gives you a URL like `https://ves-backend.onrender.com`.

### Option C — Self-host on an office computer/server

If your organisation already has a server or an always-on office PC:

1. Install Node.js on it, copy the `backend/` folder over, `npm install`,
   set `.env` with a real `API_KEY` and a `DB_PATH` on a drive that's backed up.
2. Run it with a process manager so it restarts automatically and survives
   reboots:
   ```bash
   npm install -g pm2
   pm2 start server.js --name ves-backend
   pm2 save
   pm2 startup   # follow the printed instructions to run on boot
   ```
3. Make it reachable:
   - **On the office network only:** field staff on office WiFi can already
     reach it via the PC's local IP, e.g. `http://192.168.1.20:4000`.
   - **From outside (field sites):** either port-forward on your office
     router to that PC (talk to your network/IT team — this opens the server
     to the internet, so a strong `API_KEY` and ideally HTTPS via a reverse
     proxy like Caddy or Nginx become important), or use a tunnelling service
     like [ngrok](https://ngrok.com) for a quick, temporary public URL without
     touching router settings.

### If your team later outgrows SQLite

The schema is deliberately simple (one `surveys` table). If you eventually
need multiple servers, higher write concurrency, or a managed cloud database
with its own backups (e.g. a hosted Postgres like Supabase or Neon), the same
API layer can be pointed at Postgres instead of SQLite with a fairly small
change to `db.js` and `routes/surveys.js` — ask and this can be adapted.

---

## 4. Accessing / using the database

Four ways, depending on who you are:

1. **Field staff, day to day:** just use the app's Tools → Server sync
   buttons. No direct database access needed.

2. **Office / supervisor overview:** open `<your-server-url>/admin` in any
   browser, enter the server URL and API key, and you get a sortable table of
   every survey from every device, plus a **CSV export** button for the
   whole dataset.

3. **Direct database file access (advanced):** the data lives in one file at
   whatever `DB_PATH` points to (default `backend/data/ves.db`). You can open
   it directly with the free **[DB Browser for SQLite](https://sqlitebrowser.org)**
   GUI tool to browse, query, or export it — useful for backups or one-off
   reports. If the server is actively running, either stop it first or copy
   the `.db` file elsewhere before opening it, to avoid reading a
   half-written state.

4. **Developers / scripts:** call the REST API directly, e.g.:
   ```bash
   curl https://your-server/api/surveys -H "x-api-key: YOUR_KEY"
   curl https://your-server/api/surveys/SOME_ID -H "x-api-key: YOUR_KEY"
   ```

---

## 5. Security &amp; backup notes

- Treat `API_KEY` like a password. Anyone with it can read and write all
  survey data. Don't put it in a public repo or share it outside the team.
- Deploying via Railway/Render gives you HTTPS automatically. If
  self-hosting and exposing it to the internet, put it behind HTTPS (a
  reverse proxy like Caddy makes this a one-line config) rather than plain
  `http://`.
- **Back up `ves.db` regularly** — it's the entire database in one file, so
  backing it up is just copying that file somewhere safe (or scheduling the
  admin dashboard's CSV export). Whichever hosting option you choose, make
  sure *something* is copying that file off the server periodically.
