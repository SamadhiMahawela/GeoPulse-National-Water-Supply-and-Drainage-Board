# Start Here — Setting Up the Shared Database &amp; Giving Your Team Access

This is written for someone who has never done this before. Follow it top to
bottom, in order. It should take about 30–45 minutes the first time.

**What you're building:** one server, running somewhere on the internet,
holding one shared database. Every hydrogeologist/field officer's phone or
laptop talks to that same server, so everyone sees everyone else's surveys.

---

## Before you start — what you need

- A computer (your laptop is fine) with internet access
- An email address, to create a couple of free accounts
- About 30 minutes, uninterrupted, for the first-time setup

You will create **two free accounts**: GitHub and Railway. Both are free for
what we're doing here.

---

## Part 1 — Put the code somewhere Railway can find it (GitHub)

Railway (the service that will run your server) needs to get the code from
somewhere. GitHub is the standard, free place to store it.

1. Go to **[github.com](https://github.com)** and click **Sign up**. Create a
   free account (pick any username, use your email).
2. Once logged in, click the **+** icon top-right → **New repository**.
3. Name it something like `ves-backend`. Leave everything else as default.
   Click **Create repository**.
4. You'll land on an empty repository page. Click the link that says
   **"uploading an existing file"** (it's in the text on that page).
5. Now, on your computer, open the `backend` folder you downloaded from this
   chat. **Select every file and folder inside it** (`server.js`, `db.js`,
   `package.json`, `routes`, `middleware`, `public`, `app`, `.env.example`,
   `.gitignore` — everything) and **drag them all** into the GitHub page in
   your browser.
   - Do **not** upload a `.env` file if you happen to have created one
     already — only `.env.example`. (The real `.env` is where your secret
     password goes, and that should never be uploaded anywhere public.)
6. Scroll down, click the green **Commit changes** button. Done — your code
   is now on GitHub.

---

## Part 2 — Create the server + database (Railway)

1. Go to **[railway.app](https://railway.app)** and click **Login**. Choose
   **Login with GitHub** (easiest — it connects the two automatically).
2. Click **New Project** → **Deploy from GitHub repo**.
3. Pick the `ves-backend` repository you just created. Railway will start
   building it automatically — let it run, this takes a minute or two.
4. While that's running, click on the service box that appeared (it'll be
   named after your repo) to open it, then go to the **Variables** tab.
   Add these one at a time (click **+ New Variable** each time):

   | Variable name | What to put |
   |---|---|
   | `API_KEY` | A long random password — this is the key every device needs to read/write data. Example of a good one: `nwsdb-ves-8x2f9q4m7k1z` (change it to your own random text — mash your keyboard for 20+ characters) |
   | `DB_PATH` | `/data/ves.db` |
   | `APP_USER` | A simple username for logging into the app, e.g. `nwsdb` |
   | `APP_PASSWORD` | A password for that login, e.g. `Ves2026Field!` (pick your own) |

   Leave `PORT` and `BODY_LIMIT` alone — Railway/the app handle those automatically.

5. **This step matters — don't skip it, or your data will disappear on the
   next update.** Go to the **Settings** tab of your service, find
   **Volumes**, and click **+ New Volume**. Set the **mount path** to `/data`.
   This gives your database a permanent home that survives restarts.
6. Still in **Settings**, scroll to **Networking** and click **Generate
   Domain**. Railway will give you a public web address, something like:
   ```
   https://ves-backend-production.up.railway.app
   ```
   **Write this address down — this is your Server URL. You'll need it
   everywhere below.**
7. Wait for the deployment to finish (there's a **Deployments** tab showing
   progress — wait for a green checkmark).
8. Test it: open your new address in a browser and add `/api/health` to the
   end, e.g. `https://ves-backend-production.up.railway.app/api/health`.
   You should see something like `{"ok":true,"time":...}`. That means your
   database server is alive. 🎉

**You now have a real, working, shared database on the internet.** Everything
after this point is about *using* it and *giving access* to your team.

---

## Part 3 — How to actually see/use the database

You don't need any special database software. You use it through two web pages, both part of what you just deployed:

### A) The app itself (for recording surveys)
Just open your Server URL in a browser — e.g. `https://ves-backend-production.up.railway.app`.
Since you set `APP_USER`/`APP_PASSWORD`, your browser will pop up a small
login box first — type in the username and password you chose in Part 2,
step 4. After that, you'll see the VES Field Tool app itself, already
connected to your database (no extra setup — it auto-detects its own server).

### B) The admin dashboard (for viewing everything, all devices, at once)
Go to `<your Server URL>/admin`, e.g.
`https://ves-backend-production.up.railway.app/admin`. Same login prompt.
Once in:
- Enter your **Server URL** and **API key** (the `API_KEY` you set in Part 2)
  in the two boxes on that page, click **Connect**
- You'll see a table of every survey saved by anyone, from any device
- **Export all as CSV** downloads the whole dataset as a spreadsheet file —
  this is also your easiest way to back everything up regularly

That's it — that's "having access to the database." No command line, no
special software, just those two web pages.

*(If you ever do want to peek at the raw file — e.g. to make a manual backup
copy — `backend/README.md` explains how, using a free tool called DB Browser
for SQLite. You won't need this for normal use.)*

---

## Part 4 — Giving hydrogeologists / field staff access

You don't "publish" this anywhere public (no app store, nothing searchable).
You simply **privately hand each person three things**:

1. **The web address** — your Server URL from Part 2, e.g.
   `https://ves-backend-production.up.railway.app`
2. **The login username &amp; password** — what you set as `APP_USER` /
   `APP_PASSWORD`. This is what stops random people from even opening the
   page.
3. **The API key** — what you set as `API_KEY`. The app will ask for this
   *once*, inside the app itself (Tools tab → Server sync), so their saves
   sync to the shared database.

Send these three things privately — WhatsApp, a work email, printed on a
card for the office, however your team normally shares things like this.
**Don't post it anywhere public** (a public group chat, a public website,
etc.) — anyone with all three pieces can read and write the whole database.

### What each field officer does, once, on their own phone:

1. Open the Server URL you gave them, in Chrome.
2. Enter the login username/password when prompted (their browser will
   remember it after that).
3. In the app, go to **Tools → Server sync**, paste in the **same Server
   URL** and the **API key**, tap **Save connection**, then **Test
   connection** to confirm it worked.
4. In Chrome's menu (⋮), tap **Add to Home screen** — now they have an app
   icon on their phone that opens straight to this tool.
5. That's it. From now on, every survey they save also saves to the shared
   database automatically. The **Pull latest from server** button (same tab)
   brings in everyone else's surveys too.

### Changing who has access later
- To remove someone's access entirely, change `APP_PASSWORD` and `API_KEY`
  in Railway's Variables tab (Part 2), then re-share the new values only
  with the people who should still have access. (This does mean everyone
  has to update their app once when you rotate the keys — normal for shared
  passwords like this.)
- To add a new person, just give them the same three things above.

---

## Part 5 — Installing it as a real app icon, and using it offline

Two things changed to make this work properly:

- The app now has its own icon and can be **installed** like a real app
  (opens full-screen, no browser address bar, shows up in the phone's app
  list/home screen) — this is called a "PWA" (Progressive Web App).
- It now **keeps working with zero signal** — after it's been opened once
  while connected, the phone keeps its own copy of the app itself, so no
  connection is needed to open it again later. (Entering data always worked
  offline already, since it saves to the phone first either way — what's new
  is that the *app itself* now also opens with no signal, not just the data.)

### Installing it (each field officer does this once, on their own phone)

**Important — do this step while connected to WiFi or mobile data**, so the
phone can download and store its own copy of the app:

1. Open the Server URL in Chrome (Android) or Safari (iPhone), log in with
   the username/password you gave them.
2. **On Android (Chrome):** tap the menu (⋮) → **Add to Home screen** (or
   you may see Chrome offer **Install app** directly — either works).
3. **On iPhone (Safari):** tap the **Share** icon (square with an arrow) →
   scroll down → **Add to Home Screen**.
4. A proper app icon (the navy one with the orange sounding-curve mark)
   appears on their home screen. From now on they open the app from there,
   not from the browser.

### Confirming it works offline

After installing, it's worth checking once:

1. Turn on **Airplane Mode** on the phone.
2. Open the app from its home-screen icon.
3. It should open normally, and you can add readings, save a survey, take
   photos, etc. — all fine with no signal.
4. Turn Airplane Mode back off. Go to **Tools → Server sync → Pull latest
   from server** (or just save a survey again) to sync anything you entered
   while offline up to the shared database.

That last step is the one thing to remember and tell your field team:
**data saved offline stays safely on the phone, but only reaches the shared
database once that phone is back online and syncs** (either automatically
when saving with a connection, or manually via Push/Pull in the Tools tab).
It's a good habit to open the Tools tab and tap **Push all local surveys to
server** at the end of each field day, once back in signal.



```
Server URL:      _______________________________________
Login username:  _______________________________________
Login password:  _______________________________________
API key:         _______________________________________
```

This is exactly what you hand to each new hydrogeologist or field officer —
nothing else needed.

---

## If something goes wrong

- **"I forgot the password/API key"** — go to Railway → your project → your
  service → Variables tab, they're all listed there (Railway lets you reveal
  the values).
- **"The app won't connect"** — double check the Server URL has no typo and
  starts with `https://`, and that the API key matches exactly (no extra
  spaces).
- **"It says storage is full"** — that's the phone's local browser storage,
  not the server. In the app, remove a photo/attachment or two, or export
  old surveys and clear them.
- **"The installed app won't open with no signal"** — it needs one
  successful online visit first to store its own copy (see Part 5). If
  someone installed it and immediately went offline before it finished
  loading once, have them reconnect briefly, open it once, then it'll work
  offline from then on.
- **"I updated the app's code and redeployed, but phones still show the old
  version"** — that's the offline-cache doing its job a little too well.
  It updates itself automatically the next time that phone opens the app
  *while online*; if you need it instantly, close the app fully (swipe it
  away from recent apps) and reopen it once with a connection.
- Still stuck — copy the exact error message you're seeing and ask, I can
  walk through it with you.
